import requests
from app import app, db
from datetime import date, datetime
from flask import Flask, url_for, redirect, render_template, request
from app.model.tables import Paciente, Consulta, Pagamento, TipoPlano
import json





# ROTA DE LOGIN
@app.route("/", methods=['GET', 'POST'])
def index():


    # QUANDO RECEBE OS DADOS DO FORMULÁRIO DE LOGIN
    if (request.method == 'POST'):
        pacientes = Paciente.query.all()
        email = request.form['email']
        senha = request.form['senha']

        # PERCORRE TODOS OS PACIENTES NA TABELA PACIENTE NO BANCO DE DADOS
        for paciente in pacientes:
            if (paciente.email == email) and (paciente.senha == senha):
                # REDIRECIONA PARA A ROTA DA HOMEPAGE E PASSA O ID DO PACIENTE
                return redirect(url_for('homepage', id = paciente.idPaciente))

        # RENDERIZA A TELA DE LOGIN COM A MENSAGEM DE ERRO
        return render_template("login.html", erro = "Email ou senha incorretos")


    # RENDERIZA A TELA DE LOGIN
    return render_template("login.html")





# ROTA DE CADASTRO
@app.route("/cadastro", methods=['GET', 'POST'])
def cadastro():


    # QUANDO RECEBE OS DADOS DO FORMULÁRIO DE CADASTRO
    if (request.method == 'POST'):

        # ACESSA A API VIACEP UTILIZANDO O CEP PASSADO NO CADASTRO
        urlViaCep = f"https://viacep.com.br/ws/{request.form['cep']}/json/"

        # CRIA UMA STRING COM O ENDEREÇO COMPLETO, JUNTANDO TODAS AS INFORMAÇÕES DO VIACEP + COMPLEMENTO
        logradouro = requests.get(urlViaCep).json()['logradouro']
        complemento = request.form['complemento']
        bairro = requests.get(urlViaCep).json()['bairro']
        localidade = requests.get(urlViaCep).json()['localidade']
        uf = requests.get(urlViaCep).json()['uf']
        endereco_completo = f"{logradouro}, {complemento}, {bairro} - {localidade} {uf}"

        # CRIA UM NOVO PACIENTE, PASSANDO TODOS OS DADOS DO FORMULÁRIO + ENDEREÇO COMPLETO COMO ARGUMENTO
        novoPaciente = Paciente(request.form['nome'], 
                                request.form['doc'], 
                                request.form['sexo'], 
                                request.form['nasc'], 
                                endereco_completo, 
                                request.form['telefone'], 
                                request.form['email'], 
                                request.form['senha'])

        # ADICIONA O NOVO PACIENTE AO BANCO DE DADOS
        db.session.add(novoPaciente)
        db.session.commit()

        # REDIRECIONA PARA A ROTA DE LOGIN
        return redirect(url_for('index'))


    # RENDERIZA A TELA DE CADASTRO
    return render_template("cadastro.html")





# ROTA DA HOMEPAGE
@app.route("/homepage/<id>", methods=['GET', 'POST'])
def homepage(id):


    # PEGA AS INFORMAÇÕES DO PACIENTE PELO ID PASSADO NO URL
    pacienteLog = Paciente.query.get(id)

    # RENDERIZA A TELA DA HOMEPAGE PASSANDO O PACIENTE
    return render_template("homeuser.html", paciente = pacienteLog)





# ROTA DE EDITAR CADASTRO
@app.route("/cadastro/editar/<id>", methods=['GET', 'POST'])
def editarcadastro(id):


    # PEGA AS INFORMAÇÕES DO PACIENTE PELO ID PASSADO NO URL
    pacienteLog = Paciente.query.get(id)

    # RENDERIZA A TELA DE EDIÇÃO DE CADASTRO
    return render_template("editcadastro.html", paciente = pacienteLog)





# ROTA DE AGENDAMENTO
@app.route("/agendamento/<id>", methods=['GET', 'POST'])
def agendamento(id):

    # PEGA AS INFORMAÇÕES DO PACIENTE PELO ID PASSADO NO URL
    pacienteLog = Paciente.query.get(id)

    # PEGA AS CONSULTAS
    consultas = Consulta.query.all()

    # QUANDO RECEBE OS DADOS DO FORMULÁRIO DE CADASTRO
    if (request.method == 'POST'):

        # PEGA O HORARIO PASSADO PELO FORMULÁRIO
        horaAgendada = request.form['hora']

        # PEGA A DATA PASSADA PELO FORMULÁRIO, SEPARA E CONVERTE EM OBJETO DATA
        dataAgendada = request.form['dia']
        dataAgendada = dataAgendada.split('-')
        dataAgendada = date(int(dataAgendada[0]), int(dataAgendada[1]), int(dataAgendada[2]))

        # PEGA A DATA ATUAL DO USUÁRIO
        dataAtual = date.today()

        # VERIFICA SE A DATA PASSADO PELO FORMULÁRIO É VÁLIDA
        if (dataAgendada < dataAtual):
            return render_template("agendamento.html", paciente = pacienteLog, erro = "Ops, a data inserida é inválida")

        # VERIFICA SE A DATA PASSADO PELO FORMULÁRIO ESTÁ LIVRE
        for consulta in consultas:
            if ((str(dataAgendada) == consulta.data) and (horaAgendada == consulta.horario)):
                return render_template("agendamento.html", paciente = pacienteLog, erro = "Ops, a data inserida já está marcada")

        # CRIA UM NOVO AGENDAMENTO
        novoAgendamento = Consulta(pacienteLog.idPaciente,
                                   horaAgendada,
                                   dataAgendada)

        # ADICIONA O NOVO AGENDAMENTO AO BANCO DE DADOS
        db.session.add(novoAgendamento)
        db.session.commit()

        # REDIRECIONA PARA A ROTA DE LOGIN
        return render_template("agendamento.html", paciente = pacienteLog)

    # RENDERIZA A TELA DE EDIÇÃO DE CADASTRO
    return render_template("agendamento.html", paciente = pacienteLog)